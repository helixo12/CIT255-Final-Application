﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CIT255FinalApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            {
                "Switch": [
                  {
      "id": 1,
      "name": “The legend of Zelda: Breath of the wild”,
      "sales": 10280000
    },
    {
      "id": 2,
      "name": “Super Mario Odyssey”,
      "sales": 12170000
    },
    ...
    {
      "id": 3,
      "name": “Pokemon Lets Go”,
      "sales": 1500000
    },
    {
      "id": 4,
      "name": “Mario Kart 8 Deluxe”,
      "sales": 11710000
    }
  ]
}

        }
    }
}
